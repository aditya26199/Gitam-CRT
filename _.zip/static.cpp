#include<stdio.h>
int main()
{
	static int arr[5],i;
	for(i=0;i<=5;i++)
	printf("%d",arr[i]=1);
	
}
