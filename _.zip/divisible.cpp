#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	if(a%3==0)
	{
		printf("FIZZ");
	}
	if(a%5==0)
	{
		printf("BIZZ");
	}	
	else 
	{
		printf("no");
	}
}
