#include<stdio.h>
int main()
{
	char ch;
	puts("enter a char");
	ch=getchar();
	putchar(ch);
	return 0;
}
