#include<stdio.h>
int main()
{
	char name[30];
	puts("enter your name");
	gets(name);
	puts("your name is");
	puts(name);
	return 0;
}
