#include<stdio.h>
int main()
{
	int x,y,a,b;
	printf("\n%d %d",scanf("%d %d",&a,&b),scanf("%d %d",&a,&b));
	//printf(printf("%d,%d",a,b));
	return 0;
}
