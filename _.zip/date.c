#include<stdio.h>
int main()
{
	int day,month,year;
	printf("enter the date");
	scanf("%d-%d-%d",&day,&month,&year);
	printf("the entered date is %d-%d-%d",day,month,year);
	return 0;
}
