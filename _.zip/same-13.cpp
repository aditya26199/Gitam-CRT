#include<stdio.h>
int main()
{
	int i=53,n;
	printf("enter value of n");
	scanf("%d",&n);
	printf("%d ",i);
	printf("%d ",i);
	while(i<n)
	{
		i=i-13;
	
	}
}

