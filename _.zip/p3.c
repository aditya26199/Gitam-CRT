#include<stdio.h>
int main()
{
	float  n,m;
	printf("enter two numbers");
	scanf("%2f %3f",&n,&m);
	printf("the two numbers are %f and %f",n,m);
	return 0;
}
