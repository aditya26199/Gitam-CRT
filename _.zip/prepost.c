#include<stdio.h>
int main()
{
	int x =10;
	printf("%d",x);
	printf("%d",x++);
	printf("%d",++x);	
}
