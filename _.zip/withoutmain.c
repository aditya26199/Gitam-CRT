#include<stdio.h>
#define xyz main
int xyz()
{
	int n1,n2;
	printf("enter two numbers");
	scanf("%d %d",&n1,&n2);
	printf("difference = %d",n1+~n2+1);
	printf("\n kaushal agarwal");
	return 0;
}
