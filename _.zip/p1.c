#include<stdio.h>
int main()
{
	int d,e;
	char a[]="kaushal";
	char b[]="cse";
	char c[]="gitam";
	printf("%s%s%s",a,b,c);
	printf("enter two numbers ");
	scanf("%d %d",&d,&e);
	printf("%d",d+e);
}
