#include<stdio.h>
int main()
{
int i=5,j=5;
if(i==j)
printf("eq");
else
printf("not e");
return 0;

	
}
